
<?php
    
    include "conexao.php";
    //Tratamento de erro
    if(isset($_GET['idAluno'])){
        //Entrada
        $idAluno = $_GET['idAluno'];

        //Processamento
        $sql = "delete from alunos where id = $idAluno";
        $excluir = mysqli_query($conexao,$sql);

        //Saída
        if($excluir){
            echo "<script>
            alert('Aluno excluído com sucesso!');
            window.location = 'listarAluno.php';
            </script>
            ";
        } else {
            echo "<p> Olha a merda que tu fez, derrubou o sistema. </p>
            <p> Entre em contato com o administrador do sistema. </p>";
            echo mysqli_error($conexao);
        }
    } 
    else {
        echo "<p> Esta é uma página de tratamente de dados. </p>;
        <p> Clique <a href='listarAluno.php'>aqui</a> para excluir um aluno.";
        
    }



























?>