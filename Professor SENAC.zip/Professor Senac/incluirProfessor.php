<?php
include "conexao.php";

if(isset($_POST['nome'])){
    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
    $telefone = trim($_POST['telefone']);
    $cargahoraria = trim($_POST['cargahoraria']);

    $sql = "insert into professores(nome,email,telefone,cargahoraria) values ('$nome','$email','$telefone','$cargahoraria')";
    $incluir = mysqli_query($conexao,$sql);

    if($incluir){
        echo "<script>
        alert('Usuário cadastro com sucesso!');
        window.location = 'listarProfessor.php';
        </script>";
    } else {
        echo "<p> Sistema temporariamente fora do ar. Tente novamente mais tarde. </p>;
        <p> Entre em contato com o administrador do sistema. </p>";
        echo myqsli_error($conexao);
    }
   
} else {
    echo "<p> Esta é uma página de tratamente de dados. </p>;
    <p> Clique <a href='formularioProfessor.php'> aqui </a> para incluir um professor.";
}