<?php

    include "conexao.php";
    //Tratamento de erro
    if(isset($_GET['idProfessor'])){
        //Entrada
        $idProfessor = $_GET['idProfessor'];

        //Processamento
        $sql = "delete from professores where id = $idProfessor";
        $excluir = mysqli_query($conexao,$sql);

        //Saída
        if($excluir){
            echo "<script>
            alert('Aluno excluído com sucesso!');
            window.location = 'listarProfessor.php';
            </script>";
        } else {
            echo "<p> Olha a merda que tu fez, derrubou o sistema. </p>;
            <p> Entre em contato com o administrador do sistema. </p>";
            echo myqsli_error($conexao);
        } 
    }
    else {
            echo "<p> Esta é uma página de tratamento de dados. </p>;
            <p> Clique <a href= 'listarProfessor.php>aqui</a> para excluir um professor.";
    }
    