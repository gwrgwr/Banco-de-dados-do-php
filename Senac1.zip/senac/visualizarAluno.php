<?php
    include "conexao.php";
    $erro = 0;
    if(isset($_GET['idAluno'])){
        $idAluno = $_GET['idAluno'];

        $sql = "select * from alunos where id = $idAluno";
        $seleciona = mysqli_query($conexao,$sql);
        $exibe = mysqli_fetch_array($seleciona);

        $nome = $exibe['nome'];
        $email = $exibe['email'];
        $endereco = $exibe['endereco'];
        $telefone = $exibe['telefone'];
        $turma = $exibe['turma'];
    }
        else {
            $erro++;
        }
?>
<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Visualizar Aluno</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  </head>
  <body>
    <div class="container bg-info pag">
        <div class="text-end">
            <a href="listarAluno.php"><button type="button" class="btn btn-success btn-sm">Lista de alunos
            </button>
            </a>
        </div>

        <h2> Aluno </h2>
        <hr>

        <div class="container text-start bg-gradient p-3">
            
            <?php
                if(!$erro){
                    echo "
                    <p>ID : $idAluno</p>
                    <p>Nome: $nome</p>
                    <p>Endereco: $endereco</p>
                    <p>Telefone: $telefone</p>
                    <p>E-mail: $email</p>
                    <p>Turma: $turma</p>";
                } else {
                    echo "
                    <p>Nenhum aluno foi selecionado.</p>
                    <p>Clique em Listar Alunos para selecionar um Aluno</p>";
                }
            ?>
        </div>

        <div class="row">
            <div class="col text-start">
                <a href="listarAluno.php">
                    <button type="button" class="btn btn-warning btn=sm">Voltar</button>
                </a>
            </div>
            <div class="col text-end">
                <a href="editarAluno.php">
                    <button type="button" class="btn btn-primary btn=sm">Editar dados</button>
                </a>
            </div>

        </div>    
    </div>
















    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>